/**
 * 
 */
package cl.curso.java.abstract_factory.abstract_factory_app;

/**
 * @author {Cristopher Lasalle}
 *
 */
public class MACOSXWindow implements Window {

	public void setTitle(String title) {

	}

	public void rePaint() {

	}

}
