package cl.curso.java.abstract_factory.abstract_factory_app;

public interface Window {

	public void setTitle(String title);

	public void rePaint();

}
